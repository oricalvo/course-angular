﻿import { Employee } from './employee.model';
/**
 * State
 */
export class State {
    public employees: Employee[];
}