﻿export class Employee {
    public firstName: string;
    public lastName: string;
    public id: number;
    public agaf: string;
    public empNumber: string;
    public isSelected: boolean;
}