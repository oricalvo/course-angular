﻿import { Injectable, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/first';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/filter';

import { ServerAccessService } from './server.access.service';
import { ServerModel } from '../server/servermodel';
import { Employee } from '../models/employee.model';
import { State } from '../models/state.model';

@Injectable()
export class LogicService {
    private state: State;
    private employeesSub: BehaviorSubject<Employee[]>;
    private selectedEmployeeSub: BehaviorSubject<Employee>;

    constructor(private serverAccessService: ServerAccessService) {
        this.initState();
        this.initSubjects();
        this.getEmployees();
    }

    public get selectedEmployee$(): Observable<Employee> {
        return this.selectedEmployeeSub.asObservable();
    }

    public get employees$(): Observable<Employee[]> {
        return this.employeesSub.asObservable();
    }

    public selectEmployee(id) {
        this.state.employees.map(employee => {
            let isSelected = (employee.id == id);
            employee.isSelected = isSelected;
            if (isSelected) {
                this.selectedEmployeeSub.next(this.copyOfEmployee(employee));
            }
        });
    }

    public saveState() {
        localStorage.setItem("state", JSON.stringify(this.state));
    };

    public getSavedState() {
        this.state = null;
        // get the state from where it was saved
        this.state = JSON.parse(localStorage.getItem("state"));
        // refresh the ui
        this.employeesSub.next(this.copyOfEmployees());
        this.refreshDetails();
    }

    private initState() {
        this.state = new State();
        this.state.employees = [];
    }

    private initSubjects() {
        this.selectedEmployeeSub = new BehaviorSubject<Employee>(null);
        this.employeesSub = new BehaviorSubject<Employee[]>(this.copyOfEmployees());
    }

    private getEmployees() {
        console.log("in getEmployees$");
        let fromServer = this.serverAccessService.getEmployees();
        this.convertFromServer(fromServer).forEach(
            employees => {
                this.state.employees = employees;
                this.employeesSub.next(this.copyOfEmployees());
                console.log(this.copyOfEmployees());
            }
        );
    }

    private convertFromServer(fromServer: Observable<ServerModel[]>): Observable<Employee[]> {
        return fromServer.map(response => {
            let employees: Employee[] = [];
            for (let resp of response) {
                employees.push({
                    firstName: resp.FirstName,
                    lastName: resp.LastName,
                    id: resp.Id,
                    isSelected: false,
                    agaf: resp.Agaf,
                    empNumber: resp.EmpNumber
                });
            }
            return employees;
        });
    }

    private copyOfEmployees() {
        let copyOfEmployees: Employee[] = this.state.employees.map(employee => {
            return this.copyOfEmployee(employee);
        });
        return copyOfEmployees;
    }

    private copyOfEmployee(employee): Employee {
        return Object.assign({}, employee);
    }

    private refreshDetails() {
        let selectedEmp: Employee = this.state.employees.find(employee => {
            return employee.isSelected;
        });
        this.selectedEmployeeSub.next(this.copyOfEmployee(selectedEmp));
    }
}


