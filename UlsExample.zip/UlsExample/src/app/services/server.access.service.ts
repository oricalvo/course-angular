﻿import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Http, Response } from '@angular/http';

import { MockServer } from '../server/mockServer';
import { ServerModel } from '../server/servermodel';

@Injectable()
export class ServerAccessService {
    private server: MockServer;

    constructor(private http: Http) {
        this.server = new MockServer();
    }

    public getEmployees(): Observable<ServerModel[]> {
        return this.server.getEmployees()
            .map(response => {
                let employeesFromServer = response.json() as ServerModel[];
                return employeesFromServer;
            });
    }
}






