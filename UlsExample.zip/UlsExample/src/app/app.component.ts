﻿import { Component, OnInit , OnDestroy} from '@angular/core';
import {Subscription} from "rxjs/Subscription";
import {Observable} from "rxjs/Observable";

import { LogicService } from './services/logic.service';
import { Employee } from './models/employee.model';
import { ServerModel } from './server/servermodel';

@Component({
    selector: 'my-app',
    template: `<header class="">
        <div class="system-header">
            <span class="system-logo glyphicon glyphicon-ban-circle">
                <!--החלף בתמונת המערכת-->
            </span>
            <h1>קורס מומחי ווב</h1>
            <div class="header-actions-container">
                <span class="glyphicon glyphicon-bell"></span>
                <span class="glyphicon glyphicon-search"></span>
                <span class="glyphicon glyphicon-ban-circle">
                    <!--החלף בתמונת פרופיל המשתמש-->
                </span>
            </div>
        </div>
        <div class="worksheet-header">
            <span class="worksheet-logo glyphicon glyphicon-ban-circle">
                <!--החלף בתמונת הגיליון-->
            </span>

            <h2>
                <em>
                    <!--החלף בשם הגיליון-->
                    ארכיטקטורה
                </em>
                <!--החלף בכותרת פנימית לגיליון-->
                רשימת עובדים ULS
            </h2>
        </div>
    </header>
    <main>
        <sc-listComponent [employees]="employeesInAppComp" (onSelected)="onSelectedInAppComp($event)"></sc-listComponent>
        <sc-details-component [selectedEmp]="selectedEmployee">
        </sc-details-component>
        <div class="buttonRow">
            <button type="button" (click)="saveState()">save state</button>
            <button type="button" (click)="loadState()">load state</button>
        </div>
    </main>`,
    styles:[`main,header{direction:rtl}`]
})
export class AppComponent implements OnInit, OnDestroy {
    private employeesInAppComp: Employee[];
    private employeesSub:Subscription;

    private selectedEmployee: Employee;
    private selectedEmployeeSub:Subscription;

    constructor(private logicService: LogicService) {
    }

    ngOnInit() {
        this.employeesSub = this.logicService.employees$.subscribe(employees => {
            this.employeesInAppComp = employees;
        });

        this.selectedEmployeeSub = this.logicService.selectedEmployee$.subscribe(employee => {
            this.selectedEmployee = employee;
        });
    }

    private onSelectedInAppComp(id) {
        this.logicService.selectEmployee(id);
    }

    private saveState() {
        this.logicService.saveState();
    }

    private loadState() {
        this.logicService.getSavedState();
    } 

    ngOnDestroy() {
        this.employeesSub.unsubscribe();
        this.selectedEmployeeSub.unsubscribe();
    }
}
