﻿export class ServerModel {
    public FirstName: string;
    public LastName: string;
    public Id: number;
    public Agaf: string;
    public EmpNumber: string;
}