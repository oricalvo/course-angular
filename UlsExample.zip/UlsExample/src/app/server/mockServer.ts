﻿import {Observable} from "rxjs/Observable";
import {ServerModel} from "./servermodel"
import {Http, Response, ResponseOptions} from  "@angular/http";

export class MockServer {
    public getEmployees(): Observable<Response> {
        let employees: ServerModel[] = [
            {
                "Id": 100,
                "FirstName": "MockFN1",
                "LastName": "MockLN1",
                "Agaf": "111",
                "EmpNumber": "11111"
            },
            {
                "Id": 101,
                "FirstName": "MockFN2",
                "LastName": "MockLN2",
                "Agaf": "222",
                "EmpNumber": "22222"
            },
            {
                "Id": 102,
                "FirstName": "MockFN3",
                "LastName": "MockLN3",
                "Agaf": "333",
                "EmpNumber": "33333"
            }
        ];

        return Observable.create(observable => {
            let response: Response = new Response(new ResponseOptions({
                body: employees
            }));
            observable.next(response);
            observable.complete();
        });
    }
}