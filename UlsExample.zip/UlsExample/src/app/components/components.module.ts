﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ListComponent } from './list.component/list.component';
import { DetailsComponent } from './details.component/details.component';

@NgModule({
    imports: [CommonModule],
    exports: [ListComponent, DetailsComponent],
    declarations: [ListComponent, DetailsComponent],
    providers: [],
})
export class ComponentsModule { }
