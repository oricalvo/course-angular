﻿import { Component, OnInit, Input } from '@angular/core';
import { Employee } from '../../models/employee.model';

@Component({
    selector: 'sc-details-component',
    templateUrl: 'details.component.html',
    styleUrls: ['details.component.css']
})
export class DetailsComponent implements OnInit {
    @Input() selectedEmp: Employee

    constructor() { }

    ngOnInit() { }
}
