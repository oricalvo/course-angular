"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ClassDirective = (function () {
    function ClassDirective(element, differs) {
        this.element = element;
        this.differs = differs;
    }
    ClassDirective.prototype.ngOnChanges = function () {
        this.differ = this.differs.find(this.options).create();
    };
    ClassDirective.prototype.ngDoCheck = function () {
        var _this = this;
        var changes = this.differ.diff(this.options);
        if (changes) {
            changes.forEachAddedItem(function (item) {
                console.log("forEachAddedItem", item);
                var className = item.key;
                if (item.currentValue) {
                    _this.element.nativeElement.classList.add(className);
                }
            });
            changes.forEachRemovedItem(function (item) {
                console.log("forEachRemovedItem", item);
                var className = item.key;
                if (item.previousValue) {
                    _this.element.nativeElement.classList.add(className);
                }
            });
            changes.forEachChangedItem(function (item) {
                console.log("forEachChangedItem", item);
                var className = item.key;
                if (item.currentValue) {
                    _this.element.nativeElement.classList.add(className);
                }
                else {
                    _this.element.nativeElement.classList.remove(className);
                }
            });
        }
    };
    ClassDirective.prototype.applyChanges = function () {
        for (var className in this.options) {
            if (this.options[className]) {
                this.element.nativeElement.classList.add(className);
            }
            else {
                this.element.nativeElement.classList.remove(className);
            }
        }
    };
    return ClassDirective;
}());
__decorate([
    core_1.Input("myClass"),
    __metadata("design:type", Object)
], ClassDirective.prototype, "options", void 0);
ClassDirective = __decorate([
    core_1.Directive({
        selector: "[myClass]",
    }),
    __metadata("design:paramtypes", [core_1.ElementRef, core_1.KeyValueDiffers])
], ClassDirective);
exports.ClassDirective = ClassDirective;
