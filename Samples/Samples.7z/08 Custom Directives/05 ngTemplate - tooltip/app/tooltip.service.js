"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var TooltipService = (function () {
    function TooltipService() {
    }
    TooltipService.prototype.register = function (component) {
        this.component = component;
    };
    return TooltipService;
}());
exports.TooltipService = TooltipService;
