"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ClickDirective = (function () {
    function ClickDirective(element) {
        this.element = element;
        this.ev = new core_1.EventEmitter();
    }
    ClickDirective.prototype.ngOnInit = function () {
        var _this = this;
        this.element.nativeElement.addEventListener("click", function () {
            console.log("Click detected. Waiting ...");
            var element = _this.element.nativeElement;
            var caption = element.innerText;
            element.innerText = "Processing ...";
            setTimeout(function () {
                console.log("Emitting click event");
                try {
                    var options = {};
                    _this.ev.emit(options);
                    if (options.promise) {
                        console.log("Waiting for promise to complete");
                        options.promise.then(function () {
                            console.log("Done");
                            restoreCaption();
                        }).catch(function () {
                            restoreCaption();
                        });
                    }
                    else {
                        restoreCaption();
                    }
                }
                catch (err) {
                    restoreCaption();
                }
            }, 0);
            function restoreCaption() {
                element.innerText = caption;
            }
        });
    };
    return ClickDirective;
}());
__decorate([
    core_1.Output("myClick"),
    __metadata("design:type", core_1.EventEmitter)
], ClickDirective.prototype, "ev", void 0);
ClickDirective = __decorate([
    core_1.Directive({
        selector: "[myClick]",
    }),
    __metadata("design:paramtypes", [core_1.ElementRef])
], ClickDirective);
exports.ClickDirective = ClickDirective;
