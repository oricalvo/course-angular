AppModuleInjector.prototype.getInternal = function(token,notFoundResult) {
    var self = this;
    if ((token === jit_CommonService41)) { return self._CommonService_9; }
    if ((token === jit_MainService35)) { return self._MainService_10; }
    return notFoundResult;
};
