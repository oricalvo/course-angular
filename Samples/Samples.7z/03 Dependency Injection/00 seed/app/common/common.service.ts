export class CommonService {
    constructor() {
        console.log("CommonModule: CommonService.ctor");
    }
}
