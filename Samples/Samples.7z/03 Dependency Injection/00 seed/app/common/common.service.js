"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var CommonService = (function () {
    function CommonService() {
        console.log("CommonModule: CommonService.ctor");
    }
    return CommonService;
}());
exports.CommonService = CommonService;
