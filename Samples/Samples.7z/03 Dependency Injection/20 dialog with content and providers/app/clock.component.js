"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var dialog_component_1 = require("./dialog.component");
var ClockComponent = (function () {
    function ClockComponent(dialog) {
        this.dialog = dialog;
        console.log("clock.ctor");
    }
    ClockComponent.prototype.ngOnInit = function () {
        var _this = this;
        setTimeout(function () {
            _this.dialog.close();
        }, 1500);
    };
    ClockComponent.prototype.ngOnDestroy = function () {
        console.log("clock.dtor");
    };
    return ClockComponent;
}());
ClockComponent = __decorate([
    core_1.Component({
        selector: "my-clock",
        moduleId: module.id,
        templateUrl: "./clock.component.html",
        styleUrls: ["./clock.component.css"]
    }),
    __param(0, core_1.Inject(dialog_component_1.DialogServiceToken)),
    __metadata("design:paramtypes", [Object])
], ClockComponent);
exports.ClockComponent = ClockComponent;
//# sourceMappingURL=clock.component.js.map