# angular2-min-seed
