"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var MyService = (function () {
    function MyService() {
    }
    return MyService;
}());
exports.MyService = MyService;
//# sourceMappingURL=MyService.js.map